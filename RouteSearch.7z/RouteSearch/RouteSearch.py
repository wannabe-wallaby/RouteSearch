# conding: utf-8

import numpy
import pandas
import datetime

def myprint(msg):
    print("[" + str(datetime.datetime.now()) + "]", msg)

###########################
### データ読み込み
###########################

myprint("データ読み込み start.")

link = pandas.read_csv(r"C:\work\Python\study\RouteSearch\16\台東区データ\taito_csv\CSV\リンクの情報.csv", encoding='cp932')
node = pandas.read_csv(r"C:\work\Python\study\RouteSearch\16\台東区データ\taito_csv\CSV\ノード情報.csv", encoding='cp932')

dic_node_id = {}
dic_id_node = {}
for i in range(len(node)):
    dic_node_id[node['ノードID'][i]] = i
    dic_id_node[i] = node['ノードID'][i]

myprint("データ読み込み end.")

###########################
### 実行
###########################

myprint("隣接データ作成 start.")

mat = numpy.zeros([len(dic_node_id), len(dic_node_id)], dtype='float16')

olist = link['起点ノードID']
dlist = link['終点ノードID']
clist = link['リンク延長']


for i in range(len(link)):
    onode = link['起点ノードID'][i]
    dnode = link['終点ノードID'][i]
    link_len = link['リンク延長'][i]
    mat[dic_node_id[onode], dic_node_id[dnode]] = link_len


# ファイル出力
#numpy.savetxt(r"C:\work\Python\study\RouteSearch\16\台東区データ\taito_csv\CSV\out_mst.csv", mat, delimiter=',')

# # 手入力
# mat = [
#     [0, 2, 0, 4, 9, 0, 0],
#     [2, 0, 8, 6, 0, 0, 0],
#     [0, 8, 0, 0, 0, 0, 1],
#     [4, 6, 0, 0, 4, 0, 2],
#     [9, 0, 0, 1, 1, 0, 0],
#     [0, 0, 0, 0, 2, 0, 3],
#     [0, 0, 3, 2, 0, 1, 0]
# ]

myprint("隣接データ作成 end.")

myprint("リンクデータ加工 start.")

dic_link_for_power = {}
dic_kiten_shuten = {}
for i in range(len(link)):
    dic_link_for_power[(link['起点ノードID'][i], link['終点ノードID'][i])] = (link['リンクID'][i], link['リンク延長'][i])

    if link['起点ノードID'][i] not in dic_kiten_shuten:
        dic_kiten_shuten[link['起点ノードID'][i]] = [link['終点ノードID'][i]]
    else:
        dic_kiten_shuten[link['起点ノードID'][i]].append(link['終点ノードID'][i])

myprint("リンクデータ加工 end.")

def search_original(m, org, des):
    # 初期設定
    max_cost = float('inf')
    unchecked = [False] * len(m)
    cost = [max_cost] * len(m)
    f_prev = [None] * len(m)

    cost[org-1] = 0
    f_prev[org-1] = org
    now = org

    while True:
        min = max_cost
        next = -1
        unchecked[now-1] = True
        for i in range(len(m)):
            if unchecked[i]:continue
            if m[now-1][i]:
                tmp_cost = m[now-1][i] + cost[now-1] 
                if cost[i] > tmp_cost:
                    cost[i] = tmp_cost
                    f_prev[i] = now
            if min > cost[i]:
                min = cost[i]
                next = i + 1
        now = next
        if next == -1:break

    return [get_path(org, des, f_prev), cost[des-1]]

def search_dijkstra(m, org, des):
    # コスト無限大を定義
    max_cost = float('inf')

    # 配列を準備
    checked = numpy.full(len(m), False)
    cost = numpy.full(len(m), [max_cost])
    f_prev = numpy.full(len(m), [None])

    # 初期化、初期処理
    cost[org] = 0
    f_prev[org] = org
    now = org
    checked[now] = True
    min_i = now

    while True:
        min = max_cost
        if checked[now]:
            pass
        for i in range(len(m)):
            if checked[i]:continue
            if m[now][i]:
                tmp_cost = cost[now] + m[now][i] 
                if cost[i] > tmp_cost:
                    cost[i] = tmp_cost
                    f_prev[i] = now
            if min > cost[i]:
                min = cost[i]
                min_i = i
                
        if now == min_i:
            # 更新なし
            break

        # 最小コストをチェック済にする
        checked[min_i] = True
        now = min_i

        if numpy.all(checked | (cost != max_cost)):
            break

    path = get_path(org, des, f_prev)

    # 結果表示
    print("org:", org, dic_id_node[org])
    print("dest:", des, dic_id_node[des])
    print("cost:", cost[des])

    for i, p in enumerate(path):
        print("route" + str(i) + ":", p, dic_id_node[p])

    return [path, cost[des]]

def print_path(f_prev, cost):
    for i in range(len(f_prev)):
        print('%d, prev = %d, cost = %d' % (i, f_prev[i], cost[i]))

def get_path(org, des, f_prev):
    path = []
    now = des
    path.append(now)
    while True:
        path.append(f_prev[now])
        if f_prev[now] == org:break
        now = f_prev[now]
    path.reverse()
    return path


def search_power(dic, org, des, depth_limit, distance_limit):

    list_discover = []
    depth = 0
    distance = float(0)

    def search(org, des, depth, distance, list_distance, list_rireki):

        if depth > depth_limit:
            # 経路数リミット越え
            print("c")
            return
        if distance > distance_limit:
            # 距離リミット越え
            print("d")
            return
        if org not in dic_kiten_shuten:
            print("<")
            return

        for shuten in dic_kiten_shuten[org]:

            depth += 1
            temp_distance = float(dic_link_for_power[(org, shuten)][1])

            # 発見->終了
            if des == shuten:
                list_rireki_copy = list_rireki.copy()
                list_rireki_copy.append(shuten)
                list_distance_copy = list_distance.copy()
                list_distance_copy.append(temp_distance)
                list_discover.append([depth, distance + temp_distance, list_distance_copy, list_rireki_copy])
                continue
            # 同じ経路を通過
            elif shuten in list_rireki:
                continue
            else:
                list_rireki_copy = list_rireki.copy()
                list_rireki_copy.append(shuten)
                list_distance_copy = list_distance.copy()
                list_distance_copy.append(temp_distance)
                print("*", end="")
                search(shuten, des, depth, distance + temp_distance, list_distance_copy, list_rireki_copy)
    
    if org in dic_kiten_shuten:
        search(org, des, depth, distance, [float(0)], [org])
    else:
        print("経路数", depth)

    for discover in list_discover:
        print("org:", org)
        print("dest:", des)
        print("cost:", discover[1])
        for i, route in enumerate(discover[3]):
            print("route" + str(i) + ":", discover[2][i], discover[3][i])
        print("")

def exec_dijkstra():
    t1 = datetime.datetime.now()
    myprint("ダイクストラ法サーチ start.")
    search_dijkstra(mat, dic_node_id['00001B000000000309CEF52663D87FC5'], dic_node_id['00001B000000000309CF74A663D0FFC5'])
    myprint("ダイクストラ法サーチ end.")
    t2 = datetime.datetime.now()
    myprint("所要時間：" + str(t2-t1))

def exec_power():
    t1 = datetime.datetime.now()
    myprint("深さ優先探索 start.")
    depth_limit = 10000
    distance_limit = 2000
    search_power(dic_link_for_power, '00001B000000000309CEF52663D87FC5', '00001B000000000309CF74A663D0FFC5', depth_limit, distance_limit)
    myprint("深さ優先探索 end.")
    t2 = datetime.datetime.now()
    myprint("所要時間：" + str(t2-t1))

exec_dijkstra()